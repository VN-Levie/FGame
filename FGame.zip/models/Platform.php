<?php

namespace Models;

use PDO;

class Platform extends Model
{
    public $id;
    public $name;
    public $description;
    public $updated_at;
    public $created_at;


}
